This assignment include fetch_clean_create_repo.py and GitApi folder

fetch_clean_create_repo.py program take input from command line and call function from GitApi library

GitApi is library contains two function create_repo and delete_repo .

