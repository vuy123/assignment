import sys
from github import Github



def remove_repo(username,password,input_repo):
	username=username.split('=')
	password=password.split('=')
	input_repo=input_repo.split('-1')
	
	git=Github(username[1],password[1])
	user=git.get_user()
	repo = user.get_repo(input_repo)
	repo.delete()
	

def create_repo(username,password,output_repo_name):
	username=username.split('=')
	password=password.split('=')
	output_repo_name=output_repo_name.split('=')

	git=Github(username[1],password[1])
	user=git.get_user()

        user.create_repo(name=output_repo_name)
	print("Created  Successfully")


