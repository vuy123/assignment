import GitApi.assignment as g
import sys

username=sys.argv[1]
password=sys.argv[2]
input_repo=sys.argv[3]
output_repo_name=sys.argv[4]

g.remove_repo(username,password,input_repo,output_repo_name)

g.create_repo(username,password,input_repo,output_repo_name)
