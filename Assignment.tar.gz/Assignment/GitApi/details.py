print("This is detail.py");
